polychemprint3.axes.lulzbotTaz6\_BP module
==========================================

.. automodule:: polychemprint3.axes.lulzbotTaz6_BP
   :members:
   :undoc-members:
   :show-inheritance:
