polychemprint3.sequence.gapLine module
======================================

.. automodule:: polychemprint3.sequence.gapLine
   :members:
   :undoc-members:
   :show-inheritance:
