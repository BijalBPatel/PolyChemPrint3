polychemprint3.sequence.basicMove module
========================================

.. automodule:: polychemprint3.sequence.basicMove
   :members:
   :undoc-members:
   :show-inheritance:
