polychemprint3.sequence.sequenceSpec module
===========================================

.. automodule:: polychemprint3.sequence.sequenceSpec
   :members:
   :undoc-members:
   :show-inheritance:
