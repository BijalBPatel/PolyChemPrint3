polychemprint3.axes.axes3DSpec module
=====================================

.. automodule:: polychemprint3.axes.axes3DSpec
   :members:
   :undoc-members:
   :show-inheritance:
