polychemprint3.sequence.pause module
====================================

.. automodule:: polychemprint3.sequence.pause
   :members:
   :undoc-members:
   :show-inheritance:
