Connecting new Hardware
=======================

Test
